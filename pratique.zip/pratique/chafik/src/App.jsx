import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Accueil from './components/Accueil'
import Contact from './components/Contact'
import './App.css'

function App() {
    <>
      <Accueil/>
      <Contact/>
    </>
  
}

export default App
