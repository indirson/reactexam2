import React from "react";


function Accueil() {
      <>
          <div className="card">
     <div className="card-header">
     </div>
     <div className="card-body">
       <h5 className="card-title">MENU</h5>
       <a  className="btn btn-primary">Acceuil</a>
       <a  className="btn btn-primary">Contact</a>
     </div>
     </div>
    </>
  }
  export default Accueil;